# bot_com_IA
Esse é um Bot para WhatsApp desenvolvido para ser apresentado no desafio Unimed Agreste 
