from selenium import webdriver
import time
import os
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import requests
import openai
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# Configurações do navegador e perfil
dir_path = os.getcwd()
chrome_options2 = Options()
chrome_options2.add_argument(r"user-data-dir=" + dir_path + "profile/zap")
driver = webdriver.Chrome(options=chrome_options2)
driver.get('https://web.whatsapp.com/')

# API para obter dados de seletor de elementos
agent = {"User-Agent": 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'}

api = requests.get("https://editacodigo.com.br/index/api-whatsapp/tWpe5sRKGRsYxizeWZv4LoMvF3cCBJJr", headers=agent)
time.sleep(1)
api = api.text.split(".n.")
bolinha_notificacao = api[3].strip()
contato_cliente = api[4].strip()
caixa_msg = api[5].strip()
msg_cliente = api[6].strip()

# Aguarda o carregamento da página do WhatsApp
time.sleep(10)

def bot():
    try:
        ###### PEGAR A MENSAGEM E CLICAR NELA
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CLASS_NAME, bolinha_notificacao))
        )
        
        bolinhas = driver.find_elements(By.CLASS_NAME, bolinha_notificacao)
        if len(bolinhas) > 0:
            clica_bolinha = bolinhas[-1]
            acao_bolinha = webdriver.common.action_chains.ActionChains(driver)
            acao_bolinha.move_to_element_with_offset(clica_bolinha, 0, -20)
            acao_bolinha.click().perform()

        ##### LER A NOVA MENSAGEM
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CLASS_NAME, msg_cliente))
        )
        todas_as_msg = driver.find_elements(By.CLASS_NAME, msg_cliente)
        msg = todas_as_msg[-1].text  # Pega a última mensagem
        print("Mensagem recebida:", msg)

        cliente = 'mensagem do cliente:'
        texto2 = 'Responda a mensagem do clente com base no proximo texto caso tenha o nome ******, caso não tenha, responda coforme sua inteligencia e busque ser direto sempre e seu nome é Geovanio'
        texto = '*****'
        questao = cliente + msg + texto2 + texto

        #### PROCESSA A MENSAGEM NA API OpenAI
        openai.api_key = "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"

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Você é um assistente."},
                {"role": "user", "content": questao}
            ],
            temperature=0.7,
            max_tokens=256,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        resposta = response['choices'][0]['message']['content'].strip()
        print("Resposta gerada:", resposta)

        # RESPONDER A MENSAGEM NO WHATSAPP
        campo_de_texto = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, caixa_msg))
        )
        campo_de_texto.click()
        time.sleep(2)
        campo_de_texto.send_keys(resposta, Keys.ENTER)
        print("Resposta enviada.")
        time.sleep(2)

        # FECHAR O CONTATO

        webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()



    except Exception as e:
        print(f"Erro encontrado: {e}")
        print('Buscando novas notificações...')

# Loop para ficar rodando o bot continuamente
while True:
    bot()
    time.sleep(10)  # Pequena pausa entre verificações

